# Projet-ISN
On peux gagner des points de technologie avec des click et idle. 
	On peux biensûr augmenter la prod. avec un bonus déblocable avec les points de technoligies.
Pour gagner des mats. -> Idle (Pas obtenable avec des click)
	On peux biensûr augmenter la prod. avec des bonus déblocables avec les points de technoligies.
	
Une méchanique de 
